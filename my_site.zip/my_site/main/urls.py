from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index),
    path('greet',views.greet),
    path('geology',views.geology),
    path('quiz1',views.quiz1),
    path('quiz2',views.quiz2),
    path('quiz3',views.quiz3),
    path('quiz4',views.quiz4),
    path('quiz5',views.quiz5),
    path('quiz6',views.quiz6),
]