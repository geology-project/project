from django.shortcuts import render

def index(request):
    return render(request, 'main/index.html')

def greet(request):
    return render(request, 'main/greet.html')

def geology(request):
    return render(request, 'main/geology.html')

def quiz1(request):
    return render(request, 'main/quiz1.html')
def quiz2(request):
    return render(request, 'main/quiz2.html')
def quiz3(request):
    return render(request, 'main/quiz3.html')
def quiz4(request):
    return render(request, 'main/quiz4.html')
def quiz5(request):
    return render(request, 'main/quiz5.html')
def quiz6(request):
    return render(request, 'main/quiz6.html')